
#> smart_ore_generation:v1.7.3/slots/random_position/try
#
# @within	smart_ore_generation:v1.7.3/slots/random_position/find_adjacent_air
#			smart_ore_generation:v1.7.3/slots/random_position/launch
#

data modify entity @s Pos set from storage smart_ore_generation:main initial_pos
function smart_ore_generation:v1.7.3/slots/random_position/apply_random
function smart_ore_generation:v1.7.3/slots/random_position/find_adjacent_air

